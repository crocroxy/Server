class LogicAvatar:
    pass